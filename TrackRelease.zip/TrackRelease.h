
#ifndef __TrackRelease__
#define __TrackRelease__

#include <Arduino.h>

/*
  TrackRelease class 
  
  created 3 Nov 2016
  by 
  http://www.arduino-modelleisenbahn.de/
*/

/* ------------------Class definition-----------------------------*/

void TrackRelease_Loop();

void TrackRelease1_Setup(int channel1, int channel2, int nOutputChannel);
void TrackRelease1_SetResetChannel(int nResetChannel);
void TrackRelease1_SetTreshold( int nTreshold );

void TrackRelease2_Setup(int channel1, int channel2, int nOutputChannel);
void TrackRelease2_SetResetChannel(int nResetChannel);
void TrackRelease2_SetTreshold( int nTreshold );

void TrackRelease3_Setup(int channel1, int channel2, int nOutputChannel);
void TrackRelease3_SetResetChannel(int nResetChannel);
void TrackRelease3_SetTreshold( int nTreshold );

/* ------------------Class definition-----------------------------*/

class CTrackRelease
{
       
    protected:
       enum STATUS {
          Status_1To2       = 1,
          Status_2To1       = 2,
          Status_Free       = 3,
          Status_NotActive  = 4
       };
       
       STATUS m_Status;
       int m_nChannel1;
       int m_nChannel2;
       int m_nResetChannel;
       int m_nOutputChannel;
       int m_nOld_value_ch1;
       int m_nOld_value_ch2;
       int m_nCounter;
	   int m_nTreshold;
       bool m_bFirstTime;

    public:

       enum RESULT {
          Result_Free      = 1,
          Result_Blocked   = 2,
          Result_Nothing   = 3,
          Result_NotActive = 4
       };
    
       CTrackRelease();

       void Setup( int channel1, int channel2, int nOutputChannel );

       CTrackRelease::RESULT Action( );

       void Reset( bool bResetOldStatusAlso = true );
	   
	   void SetTreshold( int nTreshold );
	   
	   void SetResetChannel(int nResetChannel);

       void Free();

       void Block();  

       bool IsActive();      
};

/* ——————————————————————————————*/

#endif
