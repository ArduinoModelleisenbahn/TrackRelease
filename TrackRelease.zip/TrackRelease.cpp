
#include "TrackRelease.h"

/*
  TrackRelease class 
  
  created 3 Nov 2016
  by 
  http://www.arduino-modelleisenbahn.de/
*/

/* ------------------Instance-----------------------------*/

CTrackRelease TrackRelease1;
CTrackRelease TrackRelease2;
CTrackRelease TrackRelease3;

/* ------------------Functions----------------------------*/

void TrackRelease_Loop()
{
    if( TrackRelease1.IsActive() )
        TrackRelease1.Action();
    
    if( TrackRelease2.IsActive() )
        TrackRelease2.Action();
    
    if( TrackRelease3.IsActive() )
        TrackRelease3.Action();
}

/* ------- */

void TrackRelease1_Setup(int channel1, int channel2, int nOutputChannel)
{
    TrackRelease1.Setup( channel1, channel2, nOutputChannel );
}

void TrackRelease1_SetResetChannel(int nResetChannel)
{
    TrackRelease1.SetResetChannel( nResetChannel );
}

void TrackRelease1_SetTreshold( int nTreshold )
{
    TrackRelease1.SetTreshold( nTreshold );
}

/* ------- */

void TrackRelease2_Setup(int channel1, int channel2, int nOutputChannel)
{
    TrackRelease2.Setup( channel1, channel2, nOutputChannel );
}

void TrackRelease2_SetResetChannel(int nResetChannel)
{
    TrackRelease2.SetResetChannel( nResetChannel );
}

void TrackRelease2_SetTreshold( int nTreshold )
{
    TrackRelease2.SetTreshold( nTreshold );
}

/* ------- */

void TrackRelease3_Setup(int channel1, int channel2, int nOutputChannel)
{
    TrackRelease3.Setup( channel1, channel2, nOutputChannel );
}

void TrackRelease3_SetResetChannel(int nResetChannel)
{
    TrackRelease3.SetResetChannel( nResetChannel );
}

void TrackRelease3_SetTreshold( int nTreshold )
{
    TrackRelease3.SetTreshold( nTreshold );
}

/* ------------------Class implementation-----------------*/

CTrackRelease::CTrackRelease()
{
  m_bFirstTime    = true;
  m_nTreshold     = 512;
  m_nResetChannel = -1;
  m_Status        = Status_NotActive;
}

//------------------------------------

void CTrackRelease::SetTreshold(int nTreshold)
{
  m_nTreshold = nTreshold;
}

//------------------------------------

void CTrackRelease::SetResetChannel(int nResetChannel)
{
  m_nResetChannel = nResetChannel;
  pinMode(m_nResetChannel,  INPUT);
}

//------------------------------------
   
void CTrackRelease::Setup( int channel1, int channel2, int nOutputChannel )
{
  m_nChannel1      = channel1;
  m_nChannel2      = channel2;
  m_nOutputChannel = nOutputChannel;
  m_Status         = Status_Free;
  
  //pinMode(m_nChannel1,    INPUT_PULLUP);
  //pinMode(m_nChannel2,    INPUT_PULLUP);
    
  pinMode(m_nOutputChannel, OUTPUT);
  
  Serial.begin(9600);
}

//------------------------------------

void CTrackRelease::Reset( bool bResetOldStatusAlso )
{
  m_nCounter       = 0;
  m_Status         = Status_Free;
  if( bResetOldStatusAlso )
  {
    m_nOld_value_ch1 = LOW;
    m_nOld_value_ch2 = LOW;
  }
  Free();
  Serial.println("Frei!");
}

//------------------------------------

CTrackRelease::RESULT CTrackRelease::Action( )
{
  RESULT result = Result_Nothing;
  
  if( !IsActive() )
      return Result_NotActive;

  if( m_bFirstTime )
  {
    m_bFirstTime = false;
    Reset(true);
  }

  int buttonState = digitalRead(m_nResetChannel);
  if( (m_nResetChannel > 0) && ( buttonState == HIGH ) && ( m_Status != Status_Free) )
  {
    Serial.println("Reset button was pressed!");
    Reset(true);    
  }
  else
  {
  
    int nChannel1Value  = LOW;
    int nChannel2Value  = LOW;

    int sensorValue1 = analogRead( m_nChannel1 );
    int sensorValue2 = analogRead( m_nChannel2 );

	//Serial.println(sensorValue1);
    
    if( m_nTreshold < 0 )
        sensorValue1 = sensorValue1 * -1;
	
    if( sensorValue1 < m_nTreshold )
        nChannel1Value = HIGH;

    if( sensorValue2 < m_nTreshold )
        nChannel2Value = HIGH;

    // unabhaengig vom Status: Wechsel von High -> Low ist uninteressant
    if( nChannel1Value == LOW && m_nOld_value_ch1 == HIGH )
    {
           m_nOld_value_ch1 = nChannel1Value;
           result           = Result_Nothing;
    }
    else if( nChannel2Value == LOW && m_nOld_value_ch2 == HIGH )
    {
           m_nOld_value_ch2 = nChannel2Value;
           result           = Result_Nothing;
           
    } else  if( m_Status == Status_Free )
    {
       // The first contact ...
       // Serial.println(sensorValue2);
       if( nChannel1Value == HIGH && m_nOld_value_ch1 == LOW )
       {
           m_nOld_value_ch1 = nChannel1Value;
           m_Status         = Status_1To2;
           m_nCounter++;
           Serial.println("Durchfahrt: 1 --> 2");
           Serial.println(m_nCounter);
           result           = Result_Blocked;
       }
       
       if( nChannel2Value == HIGH && m_nOld_value_ch2 == LOW )
       {
           m_nOld_value_ch2 = nChannel2Value;
           m_Status         = Status_2To1;
           m_nCounter++;
           Serial.println("Durchfahrt: 2 --> 1");
           Serial.println(m_nCounter);
           result           = Result_Blocked;
       }       
    }
    else if ( m_Status == Status_1To2 )
    {
       if( nChannel1Value == HIGH && m_nOld_value_ch1 == LOW )
       {
           m_nOld_value_ch1 = nChannel1Value;
           m_nCounter++;
           Serial.println(m_nCounter);
           result           = Result_Nothing;
       }
       else if( nChannel2Value == HIGH && m_nOld_value_ch2 == LOW )
       {
           m_nOld_value_ch2 = nChannel2Value;
           m_nCounter--;
           Serial.println(m_nCounter);
           if( m_nCounter == 0 )
               result = Result_Free;
           else
               result = Result_Nothing;
       }  
    }
    else if ( m_Status == Status_2To1 )
    {
       if( nChannel1Value == HIGH && m_nOld_value_ch1 == LOW )
       {
           m_nOld_value_ch1 = nChannel1Value;
           m_nCounter--;
           Serial.println(m_nCounter);
           if( m_nCounter == 0 )
               result = Result_Free;
           else
               result = Result_Nothing;
       }
       else if( nChannel2Value == HIGH && m_nOld_value_ch2 == LOW )
       {
           m_nOld_value_ch2 = nChannel2Value;
           m_nCounter++;
           Serial.println(m_nCounter);
           result           = Result_Nothing;           
       }  
    }

    
    switch( result )
    {
      case Result_Free:
         // Reset() calls also Free():
         Reset( false );
         break;
      case Result_Blocked:
         Block();
         break;
      case Result_Nothing:
      default:
        // Keine Aenderungen
        break;
    }
  } 
  
  return result;
}

//------------------------------------

void CTrackRelease::Free()
{
   digitalWrite(m_nOutputChannel, HIGH);
   m_Status         = Status_Free;
}

//------------------------------------

void CTrackRelease::Block()
{
   digitalWrite(m_nOutputChannel, LOW);
}

//------------------------------------

bool CTrackRelease::IsActive()
{
   return m_Status != Status_NotActive;
}

//------------------------------------
